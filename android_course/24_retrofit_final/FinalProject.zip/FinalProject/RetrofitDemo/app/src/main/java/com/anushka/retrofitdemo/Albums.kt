package com.anushka.retrofitdemo


import com.google.gson.annotations.SerializedName

class Albums : ArrayList<AlbumsItem>()