package com.anushka.viewmodelscopedemo.model

data class User(val id : Int , val name : String)