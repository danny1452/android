# Paging MovieApp Jetpack Compose

Welcome to the Pagnation in Jetpack Compose with Clean Architecture GitHub repository!

#### Image:
<div>
  <img src="https://github.com/mohammadjoumani/users_android_jetpack_compose_kotlin/assets/53276286/d4d4aba8-5101-406f-ae10-feafc138ad0e" width="150"height="300">
  <img src="https://github.com/mohammadjoumani/users_android_jetpack_compose_kotlin/assets/53276286/54e001d3-ae6f-4756-8d56-8a11e3230373" width= "150"height="300>
  <img src="https://github.com/mohammadjoumani/users_android_jetpack_compose_kotlin/assets/53276286/65b79032-f907-47f8-95d8-f301334352a9" width="150"height="300">
  <img src="https://github.com/mohammadjoumani/users_android_jetpack_compose_kotlin/assets/53276286/01af29ca-902c-4d17-af1d-533e148d4daa" width="150"height="300">
   <img src="https://github.com/mohammadjoumani/users_android_jetpack_compose_kotlin/assets/53276286/b963ca52-6d99-4d51-aaa3-1c0ed46340eb" width="150"height="300">
</div>


#### Video:


https://github.com/mohammadjoumani/paging_movie_app_jetpack_compose/assets/53276286/801d2f82-5717-4745-8735-a8e288c436dc



[Click here to read medium artical](https://medium.com/@mohammadjoumani/paging-with-clean-architecture-in-jetpack-compose-775fbf589256)
