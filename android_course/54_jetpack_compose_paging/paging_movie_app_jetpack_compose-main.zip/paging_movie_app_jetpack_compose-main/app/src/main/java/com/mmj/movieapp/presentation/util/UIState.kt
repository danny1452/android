package com.mmj.movieapp.presentation.util

enum class UIState {
    Init,
    Loading,
    Success,
    Error,
    Empty
}