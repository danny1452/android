package com.anushka.tmdbclient.presentation.di.tvshow

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class TvShowScope


